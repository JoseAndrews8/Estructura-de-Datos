#pragma once

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class ShopMenu : public System::Windows::Forms::UserControl
    {
    public:
        ShopMenu(void)
        {
            InitializeComponent();
            LoadData();
            DisplayProducts(foodProducts);
        }

    protected:
        ~ShopMenu()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        FlowLayoutPanel^ itemsPanel;
        FlowLayoutPanel^ categoriesPanel;
        Button^ foodButton;
        Button^ toysButton;
        Button^ accessoriesButton;
        TextBox^ searchTextBox;
        Button^ searchButton;
        PictureBox^ cartIcon;

        void InitializeComponent(void)
        {
            this->itemsPanel = (gcnew FlowLayoutPanel());
            this->categoriesPanel = (gcnew FlowLayoutPanel());
            this->foodButton = (gcnew Button());
            this->toysButton = (gcnew Button());
            this->accessoriesButton = (gcnew Button());
            this->searchTextBox = (gcnew TextBox());
            this->searchButton = (gcnew Button());
            this->cartIcon = (gcnew PictureBox());

            this->SuspendLayout();

            // 
            // searchTextBox
            // 
            this->searchTextBox->Location = Point(10, 10);
            this->searchTextBox->Size = System::Drawing::Size(400, 30);
            this->Controls->Add(this->searchTextBox);

            // 
            // searchButton
            // 
            this->searchButton->Size = System::Drawing::Size(30, 30);
            this->searchButton->Location = Point(420, 10);
            this->searchButton->BackgroundImage = Image::FromFile("Resources\\search.png");
            this->searchButton->BackgroundImageLayout = ImageLayout::Stretch;
            this->Controls->Add(this->searchButton);

            // 
            // cartIcon
            // 
            this->cartIcon->Size = System::Drawing::Size(30, 30);
            this->cartIcon->Location = Point(480, 10);
            this->cartIcon->BackgroundImage = Image::FromFile("Resources\\shop.png");
            this->cartIcon->BackgroundImageLayout = ImageLayout::Stretch;
            this->Controls->Add(this->cartIcon);

            // 
            // categoriesPanel
            // 
            this->categoriesPanel->Location = Point(10, 50);
            this->categoriesPanel->Size = System::Drawing::Size(520, 50);
            this->categoriesPanel->AutoScroll = true;
            this->categoriesPanel->Controls->Add(this->foodButton);
            this->categoriesPanel->Controls->Add(this->toysButton);
            this->categoriesPanel->Controls->Add(this->accessoriesButton);
            this->Controls->Add(this->categoriesPanel);

            // 
            // itemsPanel
            // 
            this->itemsPanel->Location = Point(10, 110);
            this->itemsPanel->Size = System::Drawing::Size(520, 840);
            this->itemsPanel->AutoScroll = true;
            this->Controls->Add(this->itemsPanel);

            // 
            // foodButton
            // 
            this->foodButton->Text = "Food";
            this->foodButton->Size = System::Drawing::Size(150, 30);
            this->foodButton->Click += gcnew EventHandler(this, &ShopMenu::foodButton_Click);

            // 
            // toysButton
            // 
            this->toysButton->Text = "Toys";
            this->toysButton->Size = System::Drawing::Size(150, 30);
            this->toysButton->Click += gcnew EventHandler(this, &ShopMenu::toysButton_Click);

            // 
            // accessoriesButton
            // 
            this->accessoriesButton->Text = "Accessories";
            this->accessoriesButton->Size = System::Drawing::Size(150, 30);
            this->accessoriesButton->Click += gcnew EventHandler(this, &ShopMenu::accessoriesButton_Click);

            // 
            // ShopMenu
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::FromArgb(255, 255, 255);
            this->ResumeLayout(false);
        }

        array<Tuple<String^, String^, String^>^>^ foodProducts;
        array<Tuple<String^, String^, String^>^>^ toysProducts;
        array<Tuple<String^, String^, String^>^>^ accessoriesProducts;

        void LoadData()
        {
            foodProducts = gcnew array<Tuple<String^, String^, String^>^>{
                Tuple::Create("Pedigree - Adulto", "240 Bs.", "tienda\\producto1.png"),
                    Tuple::Create("Pedigree - Adulto", "260 Bs.", "tienda\\producto2.png"),
                    Tuple::Create("Pedigree - Cachorro", "220 Bs.", "tienda\\producto3.png"),
                    Tuple::Create("Dog Chow", "239 Bs.", "tienda\\producto4.png")
            };

            toysProducts = gcnew array<Tuple<String^, String^, String^>^>{
                Tuple::Create("Producto 5", "Descripci�n del producto 5", "tienda\\producto5.png"),
                    Tuple::Create("Producto 6", "Descripci�n del producto 6", "tienda\\producto6.png")
            };

            accessoriesProducts = gcnew array<Tuple<String^, String^, String^>^>{
                Tuple::Create("Producto 7", "Descripci�n del producto 7", "tienda\\producto7.png"),
                    Tuple::Create("Producto 8", "Descripci�n del producto 8", "tienda\\producto8.png")
            };
        }

        void DisplayProducts(array<Tuple<String^, String^, String^>^>^ products)
        {
            this->itemsPanel->Controls->Clear();

            for each (Tuple<String^, String^, String^> ^ product in products) {
                Panel^ itemPanel = gcnew Panel();
                itemPanel->Size = System::Drawing::Size(500, 150);
                itemPanel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;

                PictureBox^ productImage = gcnew PictureBox();
                productImage->Location = Point(10, 10);
                productImage->Size = System::Drawing::Size(100, 130);
                productImage->SizeMode = PictureBoxSizeMode::StretchImage;
                productImage->Image = Image::FromFile(product->Item3);

                Panel^ infoPanel = gcnew Panel();
                infoPanel->Location = Point(120, 10);
                infoPanel->Size = System::Drawing::Size(360, 130);
                infoPanel->BackColor = Color::FromArgb(225, 225, 225);

                Label^ itemName = gcnew Label();
                itemName->Text = product->Item1;
                itemName->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
                itemName->ForeColor = Color::FromArgb(82, 82, 82);
                itemName->Location = Point(10, 10);
                itemName->Size = System::Drawing::Size(340, 30);

                Label^ itemDescription = gcnew Label();
                itemDescription->Text = product->Item2;
                itemDescription->Font = (gcnew System::Drawing::Font(L"Segoe UI", 10));
                itemDescription->ForeColor = Color::FromArgb(82, 82, 82);
                itemDescription->Location = Point(10, 50);
                itemDescription->Size = System::Drawing::Size(340, 30);

                Button^ addButton = gcnew Button();
                addButton->Text = "Agregar al carrito";
                addButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 8));
                addButton->ForeColor = Color::White;
                addButton->Location = Point(10, 90);
                addButton->Size = System::Drawing::Size(120, 25);
                addButton->BackColor = Color::FromArgb(82, 82, 82);
                addButton->FlatStyle = FlatStyle::Flat;
                addButton->Click += gcnew EventHandler(this, &ShopMenu::addButton_Click);

                infoPanel->Controls->Add(itemName);
                infoPanel->Controls->Add(itemDescription);
                infoPanel->Controls->Add(addButton);

                itemPanel->Controls->Add(productImage);
                itemPanel->Controls->Add(infoPanel);

                this->itemsPanel->Controls->Add(itemPanel);
            }
        }

        void addButton_Click(Object^ sender, EventArgs^ e)
        {
            MessageBox::Show("A�adido al carrito!");
        }

        void foodButton_Click(Object^ sender, EventArgs^ e)
        {
            DisplayProducts(foodProducts);
        }

        void toysButton_Click(Object^ sender, EventArgs^ e)
        {
            DisplayProducts(toysProducts);
        }

        void accessoriesButton_Click(Object^ sender, EventArgs^ e)
        {
            DisplayProducts(accessoriesProducts);
        }
    };
}

