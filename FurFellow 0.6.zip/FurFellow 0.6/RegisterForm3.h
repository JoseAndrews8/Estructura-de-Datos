#pragma once
#include "Usuario.h"
#include "Mascota.h"
#include "Perfil.h"
#include <iostream>
#include <msclr/marshal_cppstd.h>
#include <fstream>
#include "MainForm.h"

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class RegisterForm3 : public System::Windows::Forms::Form
    {
    public:
        RegisterForm3(void)
        {
            InitializeComponent();
        }

    protected:
        ~RegisterForm3()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        Label^ stepThreeLabel;
        TextBox^ petNameTextBox;
        DateTimePicker^ petBirthdatePicker;
        TextBox^ breedTextBox;
        TextBox^ speciesTextBox;
        ComboBox^ petGenderComboBox;
        Button^ finishButton;
        Label^ petNameLabel;
        Label^ petBirthdateLabel;
        Label^ breedLabel;
        Label^ speciesLabel;
        Label^ petGenderLabel;

        void InitializeComponent(void)
        {
            this->stepThreeLabel = (gcnew Label());
            this->petNameTextBox = (gcnew TextBox());
            this->petBirthdatePicker = (gcnew DateTimePicker());
            this->breedTextBox = (gcnew TextBox());
            this->speciesTextBox = (gcnew TextBox());
            this->petGenderComboBox = (gcnew ComboBox());
            this->finishButton = (gcnew Button());
            this->petNameLabel = (gcnew Label());
            this->petBirthdateLabel = (gcnew Label());
            this->breedLabel = (gcnew Label());
            this->speciesLabel = (gcnew Label());
            this->petGenderLabel = (gcnew Label());
            this->SuspendLayout();

            // 
            // RegisterForm3
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(540, 960); // Tama�o del formulario
            this->Name = L"RegisterForm3";
            this->Text = L"Register - Step 3";
            this->BackColor = System::Drawing::Color::FromArgb(12, 36, 51);
            this->ResumeLayout(false);

            // Step Three Label
            this->stepThreeLabel->Location = Point(120, 30);
            this->stepThreeLabel->Size = System::Drawing::Size(300, 40);
            this->stepThreeLabel->Text = "Tercer Paso - Datos de la Mascota";
            this->stepThreeLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 24));
            this->stepThreeLabel->ForeColor = Color::White;
            this->stepThreeLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->Controls->Add(this->stepThreeLabel);

            // Pet Name Label
            this->petNameLabel->Location = Point(120, 100);
            this->petNameLabel->Size = System::Drawing::Size(300, 20);
            this->petNameLabel->Text = "Nombre de la Mascota";
            this->petNameLabel->ForeColor = Color::White;
            this->Controls->Add(this->petNameLabel);

            // Pet Name TextBox
            this->petNameTextBox->Location = Point(120, 130);
            this->petNameTextBox->Size = System::Drawing::Size(300, 30);
            this->petNameTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->petNameTextBox);

            // Pet Birthdate Label
            this->petBirthdateLabel->Location = Point(120, 180);
            this->petBirthdateLabel->Size = System::Drawing::Size(300, 20);
            this->petBirthdateLabel->Text = "Fecha de Nacimiento";
            this->petBirthdateLabel->ForeColor = Color::White;
            this->Controls->Add(this->petBirthdateLabel);

            // Pet Birthdate Picker
            this->petBirthdatePicker->Location = Point(120, 210);
            this->petBirthdatePicker->Size = System::Drawing::Size(300, 30);
            this->petBirthdatePicker->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->petBirthdatePicker);

            // Breed Label
            this->breedLabel->Location = Point(120, 260);
            this->breedLabel->Size = System::Drawing::Size(300, 20);
            this->breedLabel->Text = "Raza";
            this->breedLabel->ForeColor = Color::White;
            this->Controls->Add(this->breedLabel);

            // Breed TextBox
            this->breedTextBox->Location = Point(120, 290);
            this->breedTextBox->Size = System::Drawing::Size(300, 30);
            this->breedTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->breedTextBox);

            // Species Label
            this->speciesLabel->Location = Point(120, 340);
            this->speciesLabel->Size = System::Drawing::Size(300, 20);
            this->speciesLabel->Text = "Especie";
            this->speciesLabel->ForeColor = Color::White;
            this->Controls->Add(this->speciesLabel);

            // Species TextBox
            this->speciesTextBox->Location = Point(120, 370);
            this->speciesTextBox->Size = System::Drawing::Size(300, 30);
            this->speciesTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->speciesTextBox);

            // Pet Gender Label
            this->petGenderLabel->Location = Point(120, 420);
            this->petGenderLabel->Size = System::Drawing::Size(300, 20);
            this->petGenderLabel->Text = "G�nero";
            this->petGenderLabel->ForeColor = Color::White;
            this->Controls->Add(this->petGenderLabel);

            // Pet Gender ComboBox
            this->petGenderComboBox->Location = Point(120, 450);
            this->petGenderComboBox->Size = System::Drawing::Size(300, 30);
            this->petGenderComboBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->petGenderComboBox->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Masculino", L"Femenino", L"Otro" });
            this->Controls->Add(this->petGenderComboBox);

            // Finish Button
            this->finishButton->Location = Point(120, 500);
            this->finishButton->Size = System::Drawing::Size(300, 40);
            this->finishButton->Text = "Finalizar";
            this->finishButton->BackColor = Color::FromArgb(255, 204, 0);
            this->finishButton->FlatStyle = FlatStyle::Flat;
            this->finishButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->finishButton->Click += gcnew EventHandler(this, &RegisterForm3::finishButton_Click);
            this->Controls->Add(this->finishButton);

            this->ResumeLayout(false);
        }

        void finishButton_Click(Object^ sender, EventArgs^ e)
        {
            // Validar los campos
            if (petNameTextBox->Text == "" || petBirthdatePicker->Text == "" || breedTextBox->Text == "" || speciesTextBox->Text == "" || petGenderComboBox->Text == "") {
                MessageBox::Show("Por favor complete todos los campos.");
                return;
            }

            // Guardar los datos en un archivo temporal
            std::ofstream tempFile("temp_user.txt", std::ios_base::app);
            tempFile << msclr::interop::marshal_as<std::string>(petNameTextBox->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(petBirthdatePicker->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(breedTextBox->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(speciesTextBox->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(petGenderComboBox->Text) << std::endl;
            tempFile.close();

            // Leer los datos del archivo temporal y crear el objeto Usuario
            std::ifstream inputFile("temp_user.txt");
            std::string email, password, fullName, nickname, birthdate, gender, petName, petBirthdate, breed, species, petGender;
            if (inputFile.is_open()) {
                getline(inputFile, email);
                getline(inputFile, password);
                getline(inputFile, fullName);
                getline(inputFile, nickname);
                getline(inputFile, birthdate);
                getline(inputFile, gender);
                getline(inputFile, petName);
                getline(inputFile, petBirthdate);
                getline(inputFile, breed);
                getline(inputFile, species);
                getline(inputFile, petGender);
                inputFile.close();
            }

            // Crear el objeto Usuario y Mascota
            std::string codigoUsuario = generarCodigoUsuario();
            Usuario nuevoUsuario(fullName, birthdate, nickname, gender, email, password, codigoUsuario);
            Mascota nuevaMascota(petName, species, breed, petBirthdate, petGender, codigoUsuario + "-01");

            // Crear el objeto Perfil y agregar la mascota
            Perfil nuevoPerfil(nuevoUsuario);
            nuevoPerfil.agregarMascota(nuevaMascota);

            // Guardar el perfil en archivo
            nuevoPerfil.guardarEnArchivo();
            std::ofstream loginFile("login_data.txt", std::ios::app);
            loginFile << codigoUsuario << std::endl;
            loginFile.close();

            // Eliminar el archivo temporal
            remove("temp_user.txt");

            // Mostrar mensaje de registro completado
            MessageBox::Show("Registro completado con �xito!");

            // Aqu� puedes redirigir al usuario a la aplicaci�n principal
            MainForm^ mainForm = gcnew MainForm();
            mainForm->Show();
            this->Close(); // Cierra el formulario actual
        }

        std::string generarCodigoUsuario()
        {
            // Implementar l�gica para generar un c�digo de usuario �nico
            srand(static_cast<unsigned>(time(0)));
            std::string codigo = "#";
            static const char alphanum[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            for (int i = 0; i < 6; ++i) {
                codigo += alphanum[rand() % (sizeof(alphanum) - 1)];
            }
            return codigo;
        }

    };
}
