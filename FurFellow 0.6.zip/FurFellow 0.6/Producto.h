#pragma once
#include <string>

class Producto {
public:
    std::string nombre;
    std::string descripcion;
    std::string imagen;
    int rating;

    Producto(std::string nombre, std::string descripcion, std::string imagen, int rating)
        : nombre(nombre), descripcion(descripcion), imagen(imagen), rating(rating) {}
};
