#pragma once
#include <string>
#include <vector>
#include "Producto.h"

class Categoria {
public:
    std::string nombre;
    std::vector<Producto> productos;

    Categoria(std::string nombre) : nombre(nombre) {}
    void agregarProducto(Producto producto) {
        productos.push_back(producto);
    }
};
