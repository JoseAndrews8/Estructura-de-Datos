#pragma once
#include "Usuario.h"
#include "Mascota.h"
#include <vector>
#include <string>
#include <fstream>
#include <iostream>


class Perfil {
private:
    Usuario usuario;
    std::vector<Mascota> mascotas;

public:
    Perfil(Usuario user) : usuario(user) {}

    Usuario getUsuario() const { return usuario; }
    std::vector<Mascota> getMascotas() const { return mascotas; }

    void agregarMascota(Mascota mascota) {
        mascotas.push_back(mascota);
    }

    void guardarEnArchivo() {
        std::string filename = "perfiles/" + usuario.getCodigoUsuario() + ".txt";
        std::ofstream file(filename);
        if (file.is_open()) {
            file << "Nombre=" << usuario.getNombreCompleto() << std::endl;
            file << "FechaNacimiento=" << usuario.getFechaNacimiento() << std::endl;
            file << "Apodo=" << usuario.getApodo() << std::endl;
            file << "Genero=" << usuario.getGenero() << std::endl;
            file << "Email=" << usuario.getGmail() << std::endl;
            file << "Contrase�a=" << usuario.getContrasenia() << std::endl;
            file << "CodigoUsuario=" << usuario.getCodigoUsuario() << std::endl;
            file << "Estado=" << usuario.getEstado() << std::endl;
            file << "IsPremium=" << usuario.getIsPremium() << std::endl;

            for (const auto& mascota : mascotas) {
                file << "MascotaNombre=" << mascota.getNombreMascota() << std::endl;
                file << "MascotaEspecie=" << mascota.getEspecie() << std::endl;
                file << "MascotaRaza=" << mascota.getRaza() << std::endl;
                file << "MascotaFechaNacimiento=" << mascota.getFechaNacimientoMascota() << std::endl;
                file << "MascotaGenero=" << mascota.getGenero() << std::endl;
                file << "MascotaCodigo=" << mascota.getCodigoMascota() << std::endl;
            }

            file.close();
        }
    }
};
