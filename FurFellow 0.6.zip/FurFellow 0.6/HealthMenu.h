#pragma once

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class HealthMenu : public System::Windows::Forms::UserControl
    {
    public:
        HealthMenu(void)
        {
            InitializeComponent();
            LoadHealthTips();
        }

    protected:
        ~HealthMenu()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        FlowLayoutPanel^ itemsPanel;

        void InitializeComponent(void)
        {
            this->itemsPanel = (gcnew FlowLayoutPanel());
            this->SuspendLayout();

            // 
            // itemsPanel
            // 
            this->itemsPanel->Location = Point(10, 10);
            this->itemsPanel->Size = System::Drawing::Size(520, 940);
            this->itemsPanel->AutoScroll = true;
            this->itemsPanel->BackColor = System::Drawing::Color::FromArgb(240, 240, 240);
            this->Controls->Add(this->itemsPanel);

            // 
            // HealthMenu
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::White;
            this->Size = System::Drawing::Size(540, 960);
            this->ResumeLayout(false);
        }

        void LoadHealthTips()
        {
            array<Tuple<String^, String^, String^, String^>^>^ healthTips = gcnew array<Tuple<String^, String^, String^, String^>^>{
                Tuple::Create("Resources/logo.png", "Calendario Visitas al Veterinario", "Aqui podes ver la fecha de citas con el veterinario", "Ver"),
                    Tuple::Create("Resources/logo.png", "Recomendaciones del Veterinario", "Aqui podes encontrar las recomendaciones sobre la salud de tu mascota", "Ver"),
                    Tuple::Create("Resources/logo.png", "Nutricion Balanceada ", "Aqui podes encontrar tips para la alimentacion saludame de tu mascota", "Ver"),
                    Tuple::Create("Resources/logo.png", "Importancia de las vacunas", "Aqui podes resolver tus dudas sobre las vacunas", "Ver"),
                    Tuple::Create("Resources/logo.png", "Entrenamiento", "Aqui podes ver como entrenar a tu mascota", "Ver"),
                    Tuple::Create("Resources/logo.png", "Higiene", "Aqui podes encontrar tips para el aseo de tu mascota", "Ver")
            };

            DisplayHealthTips(healthTips);
        }

        void DisplayHealthTips(array<Tuple<String^, String^, String^, String^>^>^ tips)
        {
            for each (Tuple<String^, String^, String^, String^> ^ tip in tips) {
                Panel^ tipPanel = gcnew Panel();
                tipPanel->Size = System::Drawing::Size(500, 200);
                tipPanel->BackColor = System::Drawing::Color::FromArgb(220, 220, 220);

                PictureBox^ tipImage = gcnew PictureBox();
                tipImage->Location = Point(10, 10);
                tipImage->Size = System::Drawing::Size(100, 100);
                tipImage->SizeMode = PictureBoxSizeMode::StretchImage;
                tipImage->Image = Image::FromFile(tip->Item1);

                Label^ tipTitle = gcnew Label();
                tipTitle->Text = tip->Item2;
                tipTitle->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
                tipTitle->Location = Point(120, 10);
                tipTitle->Size = System::Drawing::Size(370, 30);

                Label^ tipDescription = gcnew Label();
                tipDescription->Text = tip->Item3;
                tipDescription->Font = (gcnew System::Drawing::Font(L"Segoe UI", 10));
                tipDescription->Location = Point(120, 50);
                tipDescription->Size = System::Drawing::Size(370, 50);

                Button^ viewButton = gcnew Button();
                viewButton->Text = tip->Item4;
                viewButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 10));
                viewButton->Location = Point(120, 120);
                viewButton->Size = System::Drawing::Size(120, 30);
                viewButton->BackColor = Color::FromArgb(255, 204, 0);
                viewButton->FlatStyle = FlatStyle::Flat;
                viewButton->Click += gcnew EventHandler(this, &HealthMenu::viewButton_Click);

                tipPanel->Controls->Add(tipImage);
                tipPanel->Controls->Add(tipTitle);
                tipPanel->Controls->Add(tipDescription);
                tipPanel->Controls->Add(viewButton);

                this->itemsPanel->Controls->Add(tipPanel);
            }
        }

        void viewButton_Click(Object^ sender, EventArgs^ e)
        {
            MessageBox::Show("Mostrar m�s detalles del consejo de salud.");
        }
    };
}

