#pragma once
#include <string>
#include <vector>
#include <filesystem>
#include "Categoria.h"

std::vector<Categoria> leerCategoriasDeTienda() {

}
