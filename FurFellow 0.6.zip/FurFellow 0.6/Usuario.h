#pragma once
#include <string>


class Usuario {
private:
    std::string nombreCompleto;
    std::string fechaNacimiento;
    std::string apodo;
    std::string genero;
    std::string gmail;
    std::string contrasenia;
    std::string codigoUsuario;
    bool estado;
    bool isPremium;

public:
    Usuario(std::string nombre, std::string fechaNac, std::string apodo, std::string genero, std::string email, std::string contrasenia, std::string codigo)
        : nombreCompleto(nombre), fechaNacimiento(fechaNac), apodo(apodo), genero(genero), gmail(email), contrasenia(contrasenia), codigoUsuario(codigo), estado(true), isPremium(false) {}

    std::string getNombreCompleto() const { return nombreCompleto; }
    std::string getFechaNacimiento() const { return fechaNacimiento; }
    std::string getApodo() const { return apodo; }
    std::string getGenero() const { return genero; }
    std::string getGmail() const { return gmail; }
    std::string getContrasenia() const { return contrasenia; }
    std::string getCodigoUsuario() const { return codigoUsuario; }
    bool getEstado() const { return estado; }
    bool getIsPremium() const { return isPremium; }

    void setNombreCompleto(std::string nombre) { nombreCompleto = nombre; }
    void setFechaNacimiento(std::string fechaNac) { fechaNacimiento = fechaNac; }
    void setApodo(std::string apodo) { this->apodo = apodo; }
    void setGenero(std::string genero) { this->genero = genero; }
    void setGmail(std::string email) { gmail = email; }
    void setContrasenia(std::string contrasenia) { this->contrasenia = contrasenia; }
    void setEstado(bool estado) { this->estado = estado; }
    void setIsPremium(bool isPremium) { this->isPremium = isPremium; }
};
