#pragma once

public ref class Session
{
public:
    static System::String^ UserCode = nullptr;
};
