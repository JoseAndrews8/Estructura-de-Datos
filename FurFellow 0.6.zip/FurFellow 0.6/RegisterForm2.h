#pragma once
#include <iostream>
#include "RegisterForm3.h"
#include <fstream>
#include <msclr/marshal_cppstd.h>

namespace CppCLRWinFormsProject {

    
    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class RegisterForm2 : public System::Windows::Forms::Form
    {
    public:
        RegisterForm2(void)
        {
            InitializeComponent();
        }

    protected:
        ~RegisterForm2()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        Label^ stepTwoLabel;
        TextBox^ fullNameTextBox;
        TextBox^ nicknameTextBox;
        DateTimePicker^ birthdatePicker;
        ComboBox^ genderComboBox;
        Button^ nextButton;
        Label^ fullNameLabel;
        Label^ nicknameLabel;
        Label^ birthdateLabel;
        Label^ genderLabel;

        void InitializeComponent(void)
        {
            this->stepTwoLabel = (gcnew Label());
            this->fullNameTextBox = (gcnew TextBox());
            this->nicknameTextBox = (gcnew TextBox());
            this->birthdatePicker = (gcnew DateTimePicker());
            this->genderComboBox = (gcnew ComboBox());
            this->nextButton = (gcnew Button());
            this->fullNameLabel = (gcnew Label());
            this->nicknameLabel = (gcnew Label());
            this->birthdateLabel = (gcnew Label());
            this->genderLabel = (gcnew Label());
            this->SuspendLayout();

            // 
            // RegisterForm2
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(540, 960); // Tama�o del formulario
            this->Name = L"RegisterForm2";
            this->Text = L"Register - Step 2";
            this->BackColor = System::Drawing::Color::FromArgb(12, 36, 51);
            this->ResumeLayout(false);

            // Step Two Label
            this->stepTwoLabel->Location = Point(120, 30);
            this->stepTwoLabel->Size = System::Drawing::Size(300, 40);
            this->stepTwoLabel->Text = "Segundo Paso - Tus Datos";
            this->stepTwoLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 24));
            this->stepTwoLabel->ForeColor = Color::White;
            this->stepTwoLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->Controls->Add(this->stepTwoLabel);

            // Full Name Label
            this->fullNameLabel->Location = Point(120, 100);
            this->fullNameLabel->Size = System::Drawing::Size(300, 20);
            this->fullNameLabel->Text = "Nombre Completo";
            this->fullNameLabel->ForeColor = Color::White;
            this->Controls->Add(this->fullNameLabel);

            // Full Name TextBox
            this->fullNameTextBox->Location = Point(120, 130);
            this->fullNameTextBox->Size = System::Drawing::Size(300, 30);
            this->fullNameTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->fullNameTextBox);

            // Nickname Label
            this->nicknameLabel->Location = Point(120, 180);
            this->nicknameLabel->Size = System::Drawing::Size(300, 20);
            this->nicknameLabel->Text = "Apodo";
            this->nicknameLabel->ForeColor = Color::White;
            this->Controls->Add(this->nicknameLabel);

            // Nickname TextBox
            this->nicknameTextBox->Location = Point(120, 210);
            this->nicknameTextBox->Size = System::Drawing::Size(300, 30);
            this->nicknameTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->nicknameTextBox);

            // Birthdate Label
            this->birthdateLabel->Location = Point(120, 260);
            this->birthdateLabel->Size = System::Drawing::Size(300, 20);
            this->birthdateLabel->Text = "Fecha de Nacimiento";
            this->birthdateLabel->ForeColor = Color::White;
            this->Controls->Add(this->birthdateLabel);

            // Birthdate Picker
            this->birthdatePicker->Location = Point(120, 290);
            this->birthdatePicker->Size = System::Drawing::Size(300, 30);
            this->birthdatePicker->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->birthdatePicker);

            // Gender Label
            this->genderLabel->Location = Point(120, 340);
            this->genderLabel->Size = System::Drawing::Size(300, 20);
            this->genderLabel->Text = "G�nero";
            this->genderLabel->ForeColor = Color::White;
            this->Controls->Add(this->genderLabel);

            // Gender ComboBox
            this->genderComboBox->Location = Point(120, 370);
            this->genderComboBox->Size = System::Drawing::Size(300, 30);
            this->genderComboBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->genderComboBox->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Masculino", L"Femenino", L"Otro" });
            this->Controls->Add(this->genderComboBox);

            // Next Button
            this->nextButton->Location = Point(120, 430);
            this->nextButton->Size = System::Drawing::Size(300, 40);
            this->nextButton->Text = "Siguiente";
            this->nextButton->BackColor = Color::FromArgb(255, 204, 0);
            this->nextButton->FlatStyle = FlatStyle::Flat;
            this->nextButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->nextButton->Click += gcnew EventHandler(this, &RegisterForm2::nextButton_Click);
            this->Controls->Add(this->nextButton);

            this->ResumeLayout(false);
        }

        void nextButton_Click(Object^ sender, EventArgs^ e)
        {
            // Validar los campos aqu� antes de pasar al siguiente formulario
            if (fullNameTextBox->Text == "" || nicknameTextBox->Text == "" || birthdatePicker->Text == "" || genderComboBox->Text == "") {
                MessageBox::Show("Por favor complete todos los campos.");
                return;
            }

            // Guardar los datos en un archivo temporal
            std::ofstream tempFile("temp_user.txt", std::ios_base::app);
            tempFile << msclr::interop::marshal_as<std::string>(fullNameTextBox->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(nicknameTextBox->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(birthdatePicker->Text) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(genderComboBox->Text) << std::endl;
            tempFile.close();

            // Ir al siguiente formulario
            RegisterForm3^ form3 = gcnew RegisterForm3();
            form3->Show();
            this->Close(); // Cierra el formulario actual
        }
    };
}
