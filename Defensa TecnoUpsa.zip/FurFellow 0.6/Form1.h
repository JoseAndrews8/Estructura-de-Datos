#pragma once
#include "RegisterForm1.h"
#include "Session.h"
#include "MainForm.h"
#include <msclr/marshal_cppstd.h>
#include <fstream>
#include <string>

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class Form1 : public System::Windows::Forms::Form
    {
    public:
        Form1(void)
        {
            InitializeComponent();
        }

    protected:
        ~Form1()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        PictureBox^ logoPictureBox;
        TextBox^ emailTextBox;
        TextBox^ passwordTextBox;
        Button^ loginButton;
        LinkLabel^ createAccountLinkLabel;
        Label^ emailLabel;
        Label^ passwordLabel;
        Label^ mascotaLabel;
        TextBox^ mascotaTextBox;

        void InitializeComponent(void)
        {
            this->logoPictureBox = (gcnew PictureBox());
            this->emailTextBox = (gcnew TextBox());
            this->passwordTextBox = (gcnew TextBox());
            this->mascotaTextBox = (gcnew TextBox());
            this->loginButton = (gcnew Button());
            this->createAccountLinkLabel = (gcnew LinkLabel());
            this->emailLabel = (gcnew Label());
            this->passwordLabel = (gcnew Label());
            this->mascotaLabel = (gcnew Label());
            this->SuspendLayout();

            // 
            // Form1
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(540, 960);
            this->Name = L"Form1";
            this->Text = L"Form1";
            this->BackColor = System::Drawing::Color::FromArgb(12, 36, 51);
            this->ResumeLayout(false);

            // Logo PictureBox
            this->logoPictureBox->Location = Point(120, 50);
            this->logoPictureBox->Size = System::Drawing::Size(300, 300);
            this->logoPictureBox->SizeMode = PictureBoxSizeMode::StretchImage;
            this->logoPictureBox->Image = Image::FromFile("Resources\\logo.png");
            this->Controls->Add(this->logoPictureBox);

            // Email Label
            this->emailLabel->Location = Point(120, 360);
            this->emailLabel->Size = System::Drawing::Size(300, 20);
            this->emailLabel->Text = "Email";
            this->emailLabel->ForeColor = Color::White;
            this->Controls->Add(this->emailLabel);

            // Email TextBox
            this->emailTextBox->Location = Point(120, 390);
            this->emailTextBox->Size = System::Drawing::Size(300, 30);
            this->emailTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->emailTextBox);

            // Password Label
            this->passwordLabel->Location = Point(120, 440);
            this->passwordLabel->Size = System::Drawing::Size(300, 20);
            this->passwordLabel->Text = "Password";
            this->passwordLabel->ForeColor = Color::White;
            this->Controls->Add(this->passwordLabel);

            // Password TextBox
            this->passwordTextBox->Location = Point(120, 470);
            this->passwordTextBox->Size = System::Drawing::Size(300, 30);
            this->passwordTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->passwordTextBox->UseSystemPasswordChar = true;
            this->Controls->Add(this->passwordTextBox);


            // Nombre Mascota Label
            this->mascotaLabel->Location = Point(120, 520);
            this->mascotaLabel->Size = System::Drawing::Size(300, 20);
            this->mascotaLabel->Text = "Nombre de la Mascota";
            this->mascotaLabel->ForeColor = Color::White;
            this->Controls->Add(this->mascotaLabel);

            // Nombre Mascota TextBox
            this->mascotaTextBox->Location = Point(120, 550);
            this->mascotaTextBox->Size = System::Drawing::Size(300, 30);
            this->mascotaTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->mascotaTextBox);


            // Login Button
            this->loginButton->Location = Point(120, 610);
            this->loginButton->Size = System::Drawing::Size(300, 40);
            this->loginButton->Text = "Log in";
            this->loginButton->BackColor = Color::FromArgb(255, 204, 0);
            this->loginButton->FlatStyle = FlatStyle::Flat;
            this->loginButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->loginButton->Click += gcnew EventHandler(this, &Form1::loginButton_Click);
            this->Controls->Add(this->loginButton);

            // Create Account LinkLabel
            this->createAccountLinkLabel->Location = Point(170, 660);
            this->createAccountLinkLabel->Size = System::Drawing::Size(200, 20);
            this->createAccountLinkLabel->Text = "No account? Create One";
            this->createAccountLinkLabel->ForeColor = Color::White;
            this->createAccountLinkLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->createAccountLinkLabel->Click += gcnew EventHandler(this, &Form1::createAccountLinkLabel_Click);
            this->Controls->Add(this->createAccountLinkLabel);

            this->ResumeLayout(false);
        }

        void loginButton_Click(Object^ sender, EventArgs^ e)
        {
            String^ email = emailTextBox->Text;
            String^ password = passwordTextBox->Text;
            String^ mascota = mascotaTextBox->Text;

            if (verifyLogin(email, password, mascota)) {
                MessageBox::Show("Login Successful!");

                // Aqu� se establece el UserCode en la sesi�n
                Session::UserCode = getUserCode(email);

                // Proceder al siguiente formulario o ventana principal de la aplicaci�n
                MainForm^ mainForm = gcnew MainForm();
                mainForm->Show();
                this->Hide(); // Oculta el formulario de inicio de sesi�n
            }
            else {
                MessageBox::Show("Invalid email or password.");
            }
        }

        bool verifyLogin(String^ email, String^ password, String^ mascota)
        {
            std::ifstream file("login_data.txt");
            std::string line;
            std::string managedEmail = msclr::interop::marshal_as<std::string>(email);
            std::string managedPassword = msclr::interop::marshal_as<std::string>(password);
            std::string managedMascota = msclr::interop::marshal_as<std::string>(mascota);

            if (file.is_open()) {
                while (getline(file, line)) {
                    size_t firstComma = line.find(",");
                    size_t secondComma = line.find(",", firstComma + 1);
                    size_t thirdComma = line.find(",", secondComma + 1);

                    if (firstComma != std::string::npos && secondComma != std::string::npos) {
                        std::string storedEmail = line.substr(0, firstComma);
                        std::string storedPassword = line.substr(firstComma + 1, secondComma - firstComma - 1);
                        std::string storedUserCode = line.substr(secondComma + 1);
                        std::string storedMascota = line.substr(thirdComma + 1);

                        if (storedEmail == managedEmail && storedPassword == managedPassword && storedMascota == managedMascota) {
                            Session::UserCode = gcnew String(storedUserCode.c_str());
                            file.close();
                            return true;
                        }
                    }
                }
                file.close();
            }
            return false;
        }


        String^ getUserCode(String^ email)
        {
            std::ifstream file("login_data.txt");
            std::string line;
            std::string managedEmail = msclr::interop::marshal_as<std::string>(email);

            if (file.is_open()) {
                while (getline(file, line)) {
                    size_t pos = line.find(",");
                    std::string storedEmail = line.substr(0, pos);
                    if (storedEmail == managedEmail) {
                        size_t pos2 = line.find(",", pos + 1);
                        std::string userCode = line.substr(pos2 + 1);
                        file.close();
                        return gcnew String(userCode.c_str());
                    }
                }
                file.close();
            }
            return nullptr;
        }


        void createAccountLinkLabel_Click(Object^ sender, EventArgs^ e)
        {
            RegisterForm1^ registerForm = gcnew RegisterForm1();
            registerForm->Show();
            this->Hide(); // Hide the login form
        }
    };
}
