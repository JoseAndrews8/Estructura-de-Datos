#pragma once

#include <fstream>
#include <string>
#include "Session.h"
#include <msclr/marshal_cppstd.h>

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class ProfileMenu : public System::Windows::Forms::UserControl
    {
    public:
        ProfileMenu(void)
        {
            InitializeComponent();
            LoadProfileData();
        }

    protected:
        ~ProfileMenu()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        PictureBox^ profilePictureBox;
        Label^ petNameLabel;
        Label^ petAgeLabel;
        Label^ petBreedLabel;
        Button^ followButton;
        Label^ postsLabel;
        Label^ followersLabel;
        Label^ followingLabel;
        PictureBox^ postPictureBox1;
        PictureBox^ postPictureBox2;
        PictureBox^ postPictureBox3;
        PictureBox^ postPictureBox4;
        Panel^ infoPanel;

        void InitializeComponent(void)
        {
            this->profilePictureBox = (gcnew PictureBox());
            this->petNameLabel = (gcnew Label());
            this->petAgeLabel = (gcnew Label());
            this->petBreedLabel = (gcnew Label());
            this->followButton = (gcnew Button());
            this->postsLabel = (gcnew Label());
            this->followersLabel = (gcnew Label());
            this->followingLabel = (gcnew Label());
            this->postPictureBox1 = (gcnew PictureBox());
            this->postPictureBox2 = (gcnew PictureBox());
            this->postPictureBox3 = (gcnew PictureBox());
            this->postPictureBox4 = (gcnew PictureBox());
            this->infoPanel = (gcnew Panel());
            this->SuspendLayout();

            // profilePictureBox
            this->profilePictureBox->Location = Point(120, 30);
            this->profilePictureBox->Size = System::Drawing::Size(300, 300);
            this->profilePictureBox->SizeMode = PictureBoxSizeMode::StretchImage;
            this->profilePictureBox->BackColor = Color::Gray;
            this->Controls->Add(this->profilePictureBox);

            // infoPanel
            this->infoPanel->Location = Point(30, 340);
            this->infoPanel->Size = System::Drawing::Size(480, 130);
            this->Controls->Add(this->infoPanel);

            // petNameLabel
            this->petNameLabel->Location = Point(10, 10);
            this->petNameLabel->Size = System::Drawing::Size(120, 30);
            this->petNameLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 18));
            this->petNameLabel->TextAlign = ContentAlignment::MiddleLeft;
            this->petNameLabel->ForeColor = Color::FromArgb(82, 82, 82);
            this->infoPanel->Controls->Add(this->petNameLabel);

            // petAgeLabel
            this->petAgeLabel->Location = Point(10, 50);
            this->petAgeLabel->Size = System::Drawing::Size(300, 20);
            this->petAgeLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->petAgeLabel->TextAlign = ContentAlignment::MiddleLeft;
            this->petAgeLabel->ForeColor = Color::FromArgb(153, 160, 161);
            this->infoPanel->Controls->Add(this->petAgeLabel);

            // petBreedLabel
            this->petBreedLabel->Location = Point(10, 80);
            this->petBreedLabel->Size = System::Drawing::Size(300, 20);
            this->petBreedLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->petBreedLabel->TextAlign = ContentAlignment::MiddleLeft;
            this->petBreedLabel->ForeColor = Color::FromArgb(153, 160, 161);
            this->infoPanel->Controls->Add(this->petBreedLabel);

            // followButton
            this->followButton->Location = Point(330, 30);
            this->followButton->Size = System::Drawing::Size(120, 40);
            this->followButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->followButton->ForeColor = Color::White;
            this->followButton->Text = L"Follow";
            this->followButton->BackColor = Color::FromArgb(153, 160, 161);
            this->followButton->FlatStyle = FlatStyle::Flat;
            this->infoPanel->Controls->Add(this->followButton);

            // postsLabel
            this->postsLabel->Location = Point(50, 500);
            this->postsLabel->Size = System::Drawing::Size(100, 50);
            this->postsLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->postsLabel->Text = L"4\nPosts";
            this->postsLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->postsLabel->ForeColor = Color::Black;
            this->Controls->Add(this->postsLabel);

            // followersLabel
            this->followersLabel->Location = Point(200, 500);
            this->followersLabel->Size = System::Drawing::Size(100, 50);
            this->followersLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->followersLabel->Text = L"1031\nFollowers";
            this->followersLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->followersLabel->ForeColor = Color::Black;
            this->Controls->Add(this->followersLabel);

            // followingLabel
            this->followingLabel->Location = Point(350, 500);
            this->followingLabel->Size = System::Drawing::Size(100, 50);
            this->followingLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->followingLabel->Text = L"208\nFollowing";
            this->followingLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->followingLabel->ForeColor = Color::Black;
            this->Controls->Add(this->followingLabel);

            // postPictureBox1
            this->postPictureBox1->Location = Point(50, 600);
            this->postPictureBox1->Size = System::Drawing::Size(215, 215);
            this->postPictureBox1->SizeMode = PictureBoxSizeMode::StretchImage;
            this->Controls->Add(this->postPictureBox1);

            // postPictureBox2
            this->postPictureBox2->Location = Point(275, 600);
            this->postPictureBox2->Size = System::Drawing::Size(215, 215);
            this->postPictureBox2->SizeMode = PictureBoxSizeMode::StretchImage;
            this->Controls->Add(this->postPictureBox2);

            // postPictureBox3
            this->postPictureBox3->Location = Point(50, 825);
            this->postPictureBox3->Size = System::Drawing::Size(215, 215);
            this->postPictureBox3->SizeMode = PictureBoxSizeMode::StretchImage;
            this->Controls->Add(this->postPictureBox3);

            // postPictureBox4
            this->postPictureBox4->Location = Point(275, 825);
            this->postPictureBox4->Size = System::Drawing::Size(215, 215);
            this->postPictureBox4->SizeMode = PictureBoxSizeMode::StretchImage;
            this->Controls->Add(this->postPictureBox4);

            this->ResumeLayout(false);
        }

        void LoadProfileData()
        {
            std::string userCode = ConvertToStdString(Session::UserCode);
            std::string profileFile = "perfiles/" + userCode + ".txt";
            std::ifstream file(profileFile);

            if (file.is_open()) {
                std::string line;
                while (std::getline(file, line)) {
                    size_t pos = line.find("=");
                    if (pos != std::string::npos) {
                        std::string key = line.substr(0, pos);
                        std::string value = line.substr(pos + 1);

                        if (key == "MascotaNombre") {
                            this->petNameLabel->Text = gcnew String(value.c_str());
                        }
                        else if (key == "MascotaFechaNacimiento") {
                            this->petAgeLabel->Text = gcnew String(value.c_str());
                        }
                        else if (key == "MascotaRaza") {
                            this->petBreedLabel->Text = gcnew String(value.c_str());
                        }
                    }
                }
                file.close();
            }

            // cargar imagenes usando userCode
            LoadImageFromFile(this->profilePictureBox, "perfiles/" + userCode + "_profile_picture.jpg");
            LoadImageFromFile(this->postPictureBox1, "perfiles/" + userCode + "_picture1.jpg");
            LoadImageFromFile(this->postPictureBox2, "perfiles/" + userCode + "_picture2.jpg");
            LoadImageFromFile(this->postPictureBox3, "perfiles/" + userCode + "_picture3.jpg");
            LoadImageFromFile(this->postPictureBox4, "perfiles/" + userCode + "_picture4.jpg");
        }

        std::string ConvertToStdString(System::String^ str)
        {
            return msclr::interop::marshal_as<std::string>(str);
        }

        void LoadImageFromFile(PictureBox^ pictureBox, const std::string& filePath)
        {
            try {
                if (System::IO::File::Exists(gcnew String(filePath.c_str()))) {
                    pictureBox->Image = Image::FromFile(gcnew String(filePath.c_str()));
                }
                else {
                    pictureBox->Image = nullptr; // poner una imagen predeterminada
                }
            }
            catch (System::Exception^ ex) {
                //mensaje cuando no carga una imagen
                MessageBox::Show("Error loading image: " + ex->Message);
            }
        }
    };
}
