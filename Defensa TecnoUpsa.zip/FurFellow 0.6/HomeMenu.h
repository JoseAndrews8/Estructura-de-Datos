#pragma once

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class HomeMenu : public System::Windows::Forms::UserControl
    {
    public:
        HomeMenu(void)
        {
            InitializeComponent();
        }

    protected:
        ~HomeMenu()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        PictureBox^ logoPictureBox;
        Label^ welcomeLabel;
        Label^ followLabel;

        void InitializeComponent(void)
        {
            this->logoPictureBox = (gcnew PictureBox());
            this->welcomeLabel = (gcnew Label());
            this->followLabel = (gcnew Label());
            this->SuspendLayout();

            // 
            // logoPictureBox
            // 
            this->logoPictureBox->Location = Point(120, 200);
            this->logoPictureBox->Size = System::Drawing::Size(300, 300);
            this->logoPictureBox->SizeMode = PictureBoxSizeMode::StretchImage;
            this->logoPictureBox->Image = Image::FromFile("Resources/logo.png");
            this->Controls->Add(this->logoPictureBox);

            // 
            // welcomeLabel
            // 
            this->welcomeLabel->Location = Point(120, 520);
            this->welcomeLabel->Size = System::Drawing::Size(300, 30);
            this->welcomeLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 18));
            this->welcomeLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->welcomeLabel->Text = L"Bienvenido";
            this->Controls->Add(this->welcomeLabel);

            // 
            // followLabel
            // 
            this->followLabel->Location = Point(120, 560);
            this->followLabel->Size = System::Drawing::Size(300, 60);
            this->followLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->followLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->followLabel->Text = L"Sigue a otras mascotas para ver\n sus publicaciones";
            this->Controls->Add(this->followLabel);

            // 
            // HomeMenu
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::White;
            this->Size = System::Drawing::Size(540, 960);
            this->ResumeLayout(false);
        }
    };
}
