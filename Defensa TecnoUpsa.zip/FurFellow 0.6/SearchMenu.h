#pragma once

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class SearchMenu : public System::Windows::Forms::UserControl
    {
    public:
        SearchMenu(void)
        {
            InitializeComponent();
        }

    protected:
        ~SearchMenu()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        TextBox^ searchTextBox;
        Button^ searchButton;

        void InitializeComponent(void)
        {
            this->searchTextBox = (gcnew TextBox());
            this->searchButton = (gcnew Button());
            this->SuspendLayout();

            // 
            // searchTextBox
            // 
            this->searchTextBox->Location = Point(20, 20);
            this->searchTextBox->Size = System::Drawing::Size(450, 30);
            this->searchTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->Controls->Add(this->searchTextBox);

            // 
            // searchButton
            // 
            this->searchButton->Location = Point(470, 20);
            this->searchButton->Size = System::Drawing::Size(40, 30);
            this->searchButton->BackgroundImage = Image::FromFile("Resources\\search_icon.png"); // Aseg�rate de que el archivo de imagen est� en la ruta correcta
            this->searchButton->BackgroundImageLayout = ImageLayout::Stretch;
            this->searchButton->FlatStyle = FlatStyle::Flat;
            this->searchButton->Click += gcnew EventHandler(this, &SearchMenu::searchButton_Click);
            this->Controls->Add(this->searchButton);

            // 
            // SearchMenu
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::White;
            this->Size = System::Drawing::Size(540, 960);
            this->ResumeLayout(false);
        }

        void searchButton_Click(Object^ sender, EventArgs^ e)
        {
            String^ searchText = this->searchTextBox->Text;
            MessageBox::Show("Searching for: " + searchText);
        }
    };
}
