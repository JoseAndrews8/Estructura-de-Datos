#pragma once
#include <string>


class Mascota {
private:
    std::string nombreMascota;
    std::string especie;
    std::string raza;
    std::string fechaNacimientoMascota;
    std::string genero;
    std::string codigoMascota;

public:
    Mascota(std::string nombre, std::string especie, std::string raza, std::string fechaNac, std::string genero, std::string codigo)
        : nombreMascota(nombre), especie(especie), raza(raza), fechaNacimientoMascota(fechaNac), genero(genero), codigoMascota(codigo) {}

    std::string getNombreMascota() const { return nombreMascota; }
    std::string getEspecie() const { return especie; }
    std::string getRaza() const { return raza; }
    std::string getFechaNacimientoMascota() const { return fechaNacimientoMascota; }
    std::string getGenero() const { return genero; }
    std::string getCodigoMascota() const { return codigoMascota; }

    void setNombreMascota(std::string nombre) { nombreMascota = nombre; }
    void setEspecie(std::string especie) { this->especie = especie; }
    void setRaza(std::string raza) { this->raza = raza; }
    void setFechaNacimientoMascota(std::string fechaNac) { fechaNacimientoMascota = fechaNac; }
    void setGenero(std::string genero) { this->genero = genero; }
};
