#pragma once

#include "HomeMenu.h"
#include "SearchMenu.h"
#include "ShopMenu.h"
#include "HealthMenu.h"
#include "ProfileMenu.h"

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class MainForm : public System::Windows::Forms::Form
    {
    public:
        MainForm(void)
        {
            InitializeComponent();
        }

    protected:
        ~MainForm()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        Panel^ bottomNavBar;
        Panel^ contentPanel;
        Button^ homeButton;
        Button^ searchButton;
        Button^ shopButton;
        Button^ healthButton;
        Button^ profileButton;

        void InitializeComponent(void)
        {
            this->bottomNavBar = (gcnew Panel());
            this->contentPanel = (gcnew Panel());
            this->homeButton = (gcnew Button());
            this->searchButton = (gcnew Button());
            this->shopButton = (gcnew Button());
            this->healthButton = (gcnew Button());
            this->profileButton = (gcnew Button());

            // 
            // bottomNavBar
            // 
            this->bottomNavBar->BackColor = Color::White;
            this->bottomNavBar->Location = Point(0, 900);
            this->bottomNavBar->Size = System::Drawing::Size(540,60);
            this->bottomNavBar->Controls->Add(this->homeButton);
            this->bottomNavBar->Controls->Add(this->searchButton);
            this->bottomNavBar->Controls->Add(this->shopButton);
            this->bottomNavBar->Controls->Add(this->healthButton);
            this->bottomNavBar->Controls->Add(this->profileButton);
            this->Controls->Add(this->bottomNavBar);

            // 
            // contentPanel
            // 
            this->contentPanel->Location = Point(0, 10);
            this->contentPanel->Size = System::Drawing::Size(540, 920);
            this->Controls->Add(this->contentPanel);

            // 
            // homeButton
            // 
            this->homeButton->Location = Point(0, 10);
            this->homeButton->Size = System::Drawing::Size(108, 40);
            this->homeButton->FlatStyle = FlatStyle::Flat;
            this->homeButton->FlatAppearance->BorderSize = 0;
            this->homeButton->BackgroundImage = Image::FromFile("Resources\\home.png"); // Cambia a la ruta de tu icono
            this->homeButton->BackgroundImageLayout = ImageLayout::Zoom;
            this->homeButton->Click += gcnew EventHandler(this, &MainForm::homeButton_Click);

            // 
            // searchButton
            // 
            this->searchButton->Location = Point(108, 10);
            this->searchButton->Size = System::Drawing::Size(108, 40);
            this->searchButton->FlatStyle = FlatStyle::Flat;
            this->searchButton->FlatAppearance->BorderSize = 0;
            this->searchButton->BackgroundImage = Image::FromFile("Resources\\search.png"); // Cambia a la ruta de tu icono
            this->searchButton->BackgroundImageLayout = ImageLayout::Zoom;
            this->searchButton->Click += gcnew EventHandler(this, &MainForm::searchButton_Click);

            // 
            // shopButton
            // 
            this->shopButton->Location = Point(216, 10);
            this->shopButton->Size = System::Drawing::Size(108, 40);
            this->shopButton->FlatStyle = FlatStyle::Flat;
            this->shopButton->FlatAppearance->BorderSize = 0;
            this->shopButton->BackgroundImage = Image::FromFile("Resources\\shop.png"); // Cambia a la ruta de tu icono
            this->shopButton->BackgroundImageLayout = ImageLayout::Zoom;
            this->shopButton->Click += gcnew EventHandler(this, &MainForm::shopButton_Click);

            // 
            // healthButton
            // 
            this->healthButton->Location = Point(324, 10);
            this->healthButton->Size = System::Drawing::Size(108, 40);
            this->healthButton->FlatStyle = FlatStyle::Flat;
            this->healthButton->FlatAppearance->BorderSize = 0;
            this->healthButton->BackgroundImage = Image::FromFile("Resources\\health.png"); // Cambia a la ruta de tu icono
            this->healthButton->BackgroundImageLayout = ImageLayout::Zoom;
            this->healthButton->Click += gcnew EventHandler(this, &MainForm::healthButton_Click);

            // 
            // profileButton
            // 
            this->profileButton->Location = Point(432, 10);
            this->profileButton->Size = System::Drawing::Size(108, 40);
            this->profileButton->FlatStyle = FlatStyle::Flat;
            this->profileButton->FlatAppearance->BorderSize = 0;
            this->profileButton->BackgroundImage = Image::FromFile("Resources\\profile.png"); // Cambia a la ruta de tu icono
            this->profileButton->BackgroundImageLayout = ImageLayout::Zoom;
            this->profileButton->Click += gcnew EventHandler(this, &MainForm::profileButton_Click);

            // 
            // MainForm
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(540, 960);
            this->Name = L"MainForm";
            this->Text = L"MainForm";
            this->ResumeLayout(false);

            // Inicializar con el HomeMenu
            this->homeButton_Click(nullptr, nullptr);
        }

        void homeButton_Click(Object^ sender, EventArgs^ e)
        {
            // C�digo para mostrar el HomeMenu
            this->contentPanel->Controls->Clear();
            HomeMenu^ homeMenu = gcnew HomeMenu();
            homeMenu->Dock = DockStyle::Fill;
            this->contentPanel->Controls->Add(homeMenu);
        }

        void searchButton_Click(Object^ sender, EventArgs^ e)
        {
            // C�digo para mostrar el SearchMenu
            this->contentPanel->Controls->Clear();
            SearchMenu^ searchMenu = gcnew SearchMenu();
            searchMenu->Dock = DockStyle::Fill;
            this->contentPanel->Controls->Add(searchMenu);
        }

        void shopButton_Click(Object^ sender, EventArgs^ e)
        {
            // C�digo para mostrar el ShopMenu
            this->contentPanel->Controls->Clear();
            ShopMenu^ shopMenu = gcnew ShopMenu();
            shopMenu->Dock = DockStyle::Fill;
            this->contentPanel->Controls->Add(shopMenu);
        }

        void healthButton_Click(Object^ sender, EventArgs^ e)
        {
            // C�digo para mostrar el HealthMenu
            this->contentPanel->Controls->Clear();
            HealthMenu^ healthMenu = gcnew HealthMenu();
            healthMenu->Dock = DockStyle::Fill;
            this->contentPanel->Controls->Add(healthMenu);
        }

        void profileButton_Click(Object^ sender, EventArgs^ e)
        {
            this->contentPanel->Controls->Clear();
            ProfileMenu^ profileMenu = gcnew ProfileMenu();
            profileMenu->Dock = DockStyle::Fill;
            this->contentPanel->Controls->Add(profileMenu);
        }
    };
}
