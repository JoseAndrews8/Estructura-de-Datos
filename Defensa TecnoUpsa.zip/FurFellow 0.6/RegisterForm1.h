#pragma once
#include <iostream>
#pragma once

#include "RegisterForm2.h"
#include <fstream>
#include <msclr/marshal_cppstd.h>

namespace CppCLRWinFormsProject {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;

    public ref class RegisterForm1 : public System::Windows::Forms::Form
    {
    public:
        RegisterForm1(void)
        {
            InitializeComponent();
        }

    protected:
        ~RegisterForm1()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container^ components;
        Label^ welcomeLabel;
        Label^ stepOneLabel;
        TextBox^ emailTextBox;
        TextBox^ passwordTextBox;
        TextBox^ confirmPasswordTextBox;
        Button^ nextButton;
        Label^ emailLabel;
        Label^ passwordLabel;
        Label^ confirmPasswordLabel;

        void InitializeComponent(void)
        {
            this->welcomeLabel = (gcnew Label());
            this->stepOneLabel = (gcnew Label());
            this->emailTextBox = (gcnew TextBox());
            this->passwordTextBox = (gcnew TextBox());
            this->confirmPasswordTextBox = (gcnew TextBox());
            this->nextButton = (gcnew Button());
            this->emailLabel = (gcnew Label());
            this->passwordLabel = (gcnew Label());
            this->confirmPasswordLabel = (gcnew Label());
            this->SuspendLayout();

            // 
            // RegisterForm1
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(540, 920); // Tama�o del formulario
            this->Name = L"RegisterForm1";
            this->Text = L"Register - Step 1";
            this->BackColor = System::Drawing::Color::FromArgb(12, 36, 51);
            this->ResumeLayout(false);

            // Welcome Label
            this->welcomeLabel->Location = Point(120, 30);
            this->welcomeLabel->Size = System::Drawing::Size(300, 40);
            this->welcomeLabel->Text = "Bienvenido!!!";
            this->welcomeLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 24));
            this->welcomeLabel->ForeColor = Color::White;
            this->welcomeLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->Controls->Add(this->welcomeLabel);

            // Step One Label
            this->stepOneLabel->Location = Point(120, 80);
            this->stepOneLabel->Size = System::Drawing::Size(300, 30);
            this->stepOneLabel->Text = "Primer Paso";
            this->stepOneLabel->Font = (gcnew System::Drawing::Font(L"Segoe UI", 18));
            this->stepOneLabel->ForeColor = Color::White;
            this->stepOneLabel->TextAlign = ContentAlignment::MiddleCenter;
            this->Controls->Add(this->stepOneLabel);

            // Email Label
            this->emailLabel->Location = Point(120, 130);
            this->emailLabel->Size = System::Drawing::Size(300, 20);
            this->emailLabel->Text = "Email";
            this->emailLabel->ForeColor = Color::White;
            this->Controls->Add(this->emailLabel);

            // Email TextBox
            this->emailTextBox->Location = Point(120, 160);
            this->emailTextBox->Size = System::Drawing::Size(300, 30);
            this->emailTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->Controls->Add(this->emailTextBox);

            // Password Label
            this->passwordLabel->Location = Point(120, 210);
            this->passwordLabel->Size = System::Drawing::Size(300, 20);
            this->passwordLabel->Text = "Contrase�a";
            this->passwordLabel->ForeColor = Color::White;
            this->Controls->Add(this->passwordLabel);

            // Password TextBox
            this->passwordTextBox->Location = Point(120, 240);
            this->passwordTextBox->Size = System::Drawing::Size(300, 30);
            this->passwordTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->passwordTextBox->UseSystemPasswordChar = true;
            this->Controls->Add(this->passwordTextBox);

            // Confirm Password Label
            this->confirmPasswordLabel->Location = Point(120, 290);
            this->confirmPasswordLabel->Size = System::Drawing::Size(300, 20);
            this->confirmPasswordLabel->Text = "Confirmar Contrase�a";
            this->confirmPasswordLabel->ForeColor = Color::White;
            this->Controls->Add(this->confirmPasswordLabel);

            // Confirm Password TextBox
            this->confirmPasswordTextBox->Location = Point(120, 320);
            this->confirmPasswordTextBox->Size = System::Drawing::Size(300, 30);
            this->confirmPasswordTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12));
            this->confirmPasswordTextBox->UseSystemPasswordChar = true;
            this->Controls->Add(this->confirmPasswordTextBox);

            // Next Button
            this->nextButton->Location = Point(120, 370);
            this->nextButton->Size = System::Drawing::Size(300, 40);
            this->nextButton->Text = "Siguiente";
            this->nextButton->BackColor = Color::FromArgb(255, 204, 0);
            this->nextButton->FlatStyle = FlatStyle::Flat;
            this->nextButton->Font = (gcnew System::Drawing::Font(L"Segoe UI", 14));
            this->nextButton->Click += gcnew EventHandler(this, &RegisterForm1::nextButton_Click);
            this->Controls->Add(this->nextButton);

            this->ResumeLayout(false);
        }

        void nextButton_Click(Object^ sender, EventArgs^ e)
        {
            // Guardar los datos en un archivo temporal
            String^ email = emailTextBox->Text;
            String^ password = passwordTextBox->Text;
            String^ confirmPassword = confirmPasswordTextBox->Text;

            if (password != confirmPassword) {
                MessageBox::Show("Passwords do not match. Please try again.");
                return;
            }

            // Guardar los datos en un archivo temporal
            std::ofstream tempFile("temp_user.txt");
            tempFile << msclr::interop::marshal_as<std::string>(email) << std::endl;
            tempFile << msclr::interop::marshal_as<std::string>(password) << std::endl;
            tempFile.close();

            // Guardar los datos en login_data.txt
            std::ofstream loginFile("login_data.txt", std::ios::app);
            loginFile << msclr::interop::marshal_as<std::string>(email) << "," << msclr::interop::marshal_as<std::string>(password) << ",";
            loginFile.close();

            RegisterForm2^ form2 = gcnew RegisterForm2();
            form2->Show();
            this->Close(); // Cierra el formulario actual
        }
    };
}